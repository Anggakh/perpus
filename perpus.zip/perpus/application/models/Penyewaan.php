<?php
class penyewaan extends CI_Model
{
	public function tampil_data_lapangan($kode)
	{
		if ($kode=='all'){
			$hasil=$this->db->get('lapangan');
	}else{
			$this->db->where('ID_lapangan',$kode);
			$hasil=$this->db->get('lapangan');
		}
		return $hasil->result();
	}
	public function simpan_data_lapangan($data)
	{
		if ($data['mode']=='baru'){
			unset($data['mode']);
			$hasil=$this->db->insert('lapangan', $data); 
		}else{
			unset($data['mode']);
			$this->db->where('ID_lapangan',$data['ID_lapangan']);
			$hasil=$this->db->update('lapangan', $data); 
		}
		return $hasil;
	}
	public function hapus_data_lapangan($kode)
	{
		$this->db->where('ID_lapangan', $kode);
		$hasil=$this->db->delete('lapangan'); 
		return $hasil;
	}
}
?>