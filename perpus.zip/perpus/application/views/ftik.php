<!DOCTYPE html>
<html>

		<head>
				<title>Fakultas TIK</title>
		</head>
		<body>
				<h1>Selamat Datang di Fakultas TIK</h1>
		</body>
</html>